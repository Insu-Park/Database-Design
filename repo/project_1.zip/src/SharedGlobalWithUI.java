import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class SharedGlobalWithUI {
    
	public static Map<String,Item> displayItems = new HashMap<String,Item>(); //string: 바코드(itemNo(9)+exdate)
    
	//바코드를 검색하면 테이블에 추가되도록 갱신
	public static void Invalidate() {
    	test_01 window = test_01.getInstance();
    	int rowcnt = 0;
    	window.model.setNumRows(0);
    	String inputStr[] = new String[5];
    	/*for(int i=0; i<5; i++ ) {
    	inputStr[0] = "안";
        inputStr[1] = "녕";
        inputStr[2] = "하";
        inputStr[3] = "세";
        inputStr[4] = "요";
        window.model.addRow(inputStr);
    	}*/
    	for (Map.Entry<String, Item> entry : SharedGlobalWithUI.displayItems.entrySet()) {
            String key = entry.getKey();
            Item value = entry.getValue();
            
            inputStr[0] = value.itemNo;
            inputStr[1] = value.itemName;
            inputStr[2] = Integer.toString(value.price);
            inputStr[3] = Integer.toString(value.qty);
            inputStr[4] = Integer.toString(value.qty*value.price);
            window.model.addRow(inputStr);
            
        }
    }
    
    //public static Sell toBeRefunded = new Sell();
    public static int workingStaffNo;
    public static void PopUpError(String msg){
        // 동수 do
        // 에러 메세지 창 팝업
        System.out.println("Err msg Pop Up!");
    }
    public static String customSex, customRageCd;
    
}
