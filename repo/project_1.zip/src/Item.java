public class Item {
    public String itemNo, itemName; // ITEM_NO, ITEM_NAME
    public String exdate;
    public int qty, price; // 수량, 개당가격
    public boolean isExdateImpt; // 유통기한 중요 여부; true = 중요
}
